drop policy if exists "authenticated users can create notifications" on notifications;

create policy "authenticated users can create notifications"
on notifications for insert
to authenticated
with check (auth.uid() is not null);

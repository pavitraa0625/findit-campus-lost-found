-- FindIt return confirmation + admin management upgrade
-- Paste this whole file into Supabase SQL Editor and run it once.

alter table items
add column if not exists resolved_at timestamptz,
add column if not exists resolution_source text default 'user',
add column if not exists moderation_status text default 'active';

alter table claims
add column if not exists return_initiated_by uuid references auth.users(id) on delete set null,
add column if not exists return_initiated_at timestamptz,
add column if not exists return_owner_confirmed_at timestamptz,
add column if not exists return_requester_confirmed_at timestamptz,
add column if not exists return_confirmed_at timestamptz;

alter table items
drop constraint if exists items_status_check;

alter table items
add constraint items_status_check
check (status in ('open', 'return_pending', 'resolved'));

alter table items
drop constraint if exists items_moderation_status_check;

alter table items
add constraint items_moderation_status_check
check (moderation_status in ('active', 'hidden', 'flagged'));

create or replace function findit_is_admin()
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1
    from profiles
    where id = auth.uid()
      and role = 'admin'
  );
$$;

drop policy if exists "admins can update all items" on items;
drop policy if exists "admins can delete all items" on items;
drop policy if exists "admins can view all claims" on claims;
drop policy if exists "admins can update all claims" on claims;
drop policy if exists "claim requesters can confirm returns" on claims;

create policy "admins can update all items"
on items for update
to authenticated
using (findit_is_admin())
with check (findit_is_admin());

create policy "admins can delete all items"
on items for delete
to authenticated
using (findit_is_admin());

create policy "admins can view all claims"
on claims for select
to authenticated
using (findit_is_admin());

create policy "admins can update all claims"
on claims for update
to authenticated
using (findit_is_admin())
with check (findit_is_admin());

create policy "claim requesters can confirm returns"
on claims for update
to authenticated
using (requester_id = auth.uid())
with check (requester_id = auth.uid());

update items
set resolved_at = coalesce(resolved_at, updated_at)
where status = 'resolved'
  and resolved_at is null;

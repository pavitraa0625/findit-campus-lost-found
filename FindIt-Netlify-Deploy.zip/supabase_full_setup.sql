-- FindIt complete Supabase backend setup / upgrade
-- Paste this whole file into Supabase SQL Editor and run it.

-- Extensions
create extension if not exists pgcrypto;

-- Core tables
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique,
  full_name text,
  roll_number text,
  role text default 'student',
  phone text,
  alternate_contact text,
  created_at timestamptz default now()
);

create table if not exists items (
  id uuid primary key default gen_random_uuid(),
  type text not null check (type in ('lost', 'found')),
  title text not null,
  category text,
  item_date date,
  location text,
  description text,
  photo_url text,
  photo_urls jsonb default '[]'::jsonb,
  keywords text[] default '{}',
  status text default 'open' check (status in ('open', 'resolved')),
  reporter_id uuid references auth.users(id) on delete cascade,
  contact text,
  contact_privacy text default 'claim-only',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists claims (
  id uuid primary key default gen_random_uuid(),
  item_id uuid references items(id) on delete cascade,
  requester_id uuid references auth.users(id) on delete cascade,
  message text,
  status text default 'pending' check (status in ('pending', 'approved', 'rejected')),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  item_id uuid references items(id) on delete cascade,
  matched_item_id uuid references items(id) on delete set null,
  type text,
  message text,
  match_key text,
  read boolean default false,
  created_at timestamptz default now()
);

create table if not exists item_matches (
  id uuid primary key default gen_random_uuid(),
  match_key text not null unique,
  lost_item_id uuid not null references items(id) on delete cascade,
  found_item_id uuid not null references items(id) on delete cascade,
  score integer not null default 0,
  reasons text[] not null default '{}',
  created_at timestamptz not null default now()
);

-- Upgrade existing installs safely
alter table profiles
add column if not exists email text unique,
add column if not exists phone text,
add column if not exists alternate_contact text;

alter table items
add column if not exists photo_urls jsonb default '[]'::jsonb,
add column if not exists keywords text[] default '{}';

alter table notifications
add column if not exists matched_item_id uuid references items(id) on delete set null,
add column if not exists match_key text;

create unique index if not exists notifications_user_match_unique
on notifications(user_id, type, match_key)
where match_key is not null;

-- Fix old roll numbers like U4CSE... into BL.EN.U4CSE...
update profiles
set roll_number = 'BL.EN.' || upper((regexp_match(coalesce(roll_number, email, ''), 'u[0-9][a-z]+[0-9]*', 'i'))[1])
where coalesce(roll_number, email, '') ~* 'u[0-9][a-z]+[0-9]*'
  and coalesce(roll_number, '') !~* '^BL\.EN\.';

-- RLS
alter table profiles enable row level security;
alter table items enable row level security;
alter table claims enable row level security;
alter table notifications enable row level security;

drop policy if exists "profiles are readable by logged in users" on profiles;
drop policy if exists "users can update own profile" on profiles;
drop policy if exists "users can insert own profile" on profiles;
drop policy if exists "items are publicly readable" on items;
drop policy if exists "logged in users can create items" on items;
drop policy if exists "users can update own items" on items;
drop policy if exists "users can delete own items" on items;
drop policy if exists "users can create claims" on claims;
drop policy if exists "users can view related claims" on claims;
drop policy if exists "item owners can update claims" on claims;
drop policy if exists "users can view own notifications" on notifications;
drop policy if exists "users can update own notifications" on notifications;
drop policy if exists "authenticated users can create notifications" on notifications;

create policy "profiles are readable by logged in users"
on profiles for select
to authenticated
using (true);

create policy "users can update own profile"
on profiles for update
to authenticated
using (auth.uid() = id)
with check (auth.uid() = id);

create policy "users can insert own profile"
on profiles for insert
to authenticated
with check (auth.uid() = id);

create policy "items are publicly readable"
on items for select
to authenticated
using (true);

create policy "logged in users can create items"
on items for insert
to authenticated
with check (auth.uid() = reporter_id);

create policy "users can update own items"
on items for update
to authenticated
using (auth.uid() = reporter_id)
with check (auth.uid() = reporter_id);

create policy "users can delete own items"
on items for delete
to authenticated
using (auth.uid() = reporter_id);

create policy "users can create claims"
on claims for insert
to authenticated
with check (auth.uid() = requester_id);

create policy "users can view related claims"
on claims for select
to authenticated
using (
  requester_id = auth.uid()
  or exists (
    select 1
    from items
    where items.id = claims.item_id
      and items.reporter_id = auth.uid()
  )
);

create policy "item owners can update claims"
on claims for update
to authenticated
using (
  exists (
    select 1
    from items
    where items.id = claims.item_id
      and items.reporter_id = auth.uid()
  )
);

create policy "users can view own notifications"
on notifications for select
to authenticated
using (user_id = auth.uid());

create policy "users can update own notifications"
on notifications for update
to authenticated
using (user_id = auth.uid())
with check (user_id = auth.uid());

create policy "authenticated users can create notifications"
on notifications for insert
to authenticated
with check (auth.uid() is not null);

-- Realtime
alter table items replica identity full;
alter table claims replica identity full;
alter table notifications replica identity full;

do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    if not exists (
      select 1 from pg_publication_tables
      where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'items'
    ) then
      alter publication supabase_realtime add table items;
    end if;

    if not exists (
      select 1 from pg_publication_tables
      where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'claims'
    ) then
      alter publication supabase_realtime add table claims;
    end if;

    if not exists (
      select 1 from pg_publication_tables
      where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'notifications'
    ) then
      alter publication supabase_realtime add table notifications;
    end if;
  end if;
end $$;

-- Matching helpers
create or replace function findit_normalize_token(token text)
returns text
language sql
immutable
as $$
  select case
    when lower(token) in ('cellphone', 'mobile', 'smartphone') then 'phone'
    when lower(token) in ('purse', 'billfold') then 'wallet'
    when lower(token) in ('spectacles', 'specs') then 'glasses'
    when lower(token) in ('earphones', 'headphones') then 'earbuds'
    when lower(token) = 'charger' then 'adapter'
    when lower(token) = 'pendrive' then 'usb'
    when lower(token) in ('idcard', 'identity') then 'id'
    when lower(token) ~ 'ies$' and length(token) > 4 then regexp_replace(lower(token), 'ies$', 'y')
    when lower(token) ~ 'es$' and length(token) > 4 then regexp_replace(lower(token), 'es$', '')
    when lower(token) ~ 's$' and length(token) > 3 then regexp_replace(lower(token), 's$', '')
    else lower(token)
  end;
$$;

create or replace function findit_keywords(
  title text,
  description text,
  location text,
  category text,
  keywords text[]
) returns text[]
language sql
immutable
as $$
  select array(
    select distinct findit_normalize_token(raw_token) as token
    from regexp_split_to_table(
      lower(coalesce(title, '') || ' ' || coalesce(description, '') || ' ' || coalesce(location, '') || ' ' || coalesce(category, '') || ' ' || array_to_string(coalesce(keywords, '{}'), ' ')),
      '[^a-z0-9]+'
    ) as tokens(raw_token)
    where length(findit_normalize_token(raw_token)) > 2
      and findit_normalize_token(raw_token) not in (
        'the', 'and', 'for', 'with', 'near', 'from', 'this', 'that', 'item', 'lost', 'found',
        'please', 'kindly', 'small', 'large', 'medium', 'short', 'long', 'one'
      )
  );
$$;

create or replace function findit_match_score(new_item items, candidate items)
returns table(score integer, reasons text[])
language plpgsql
stable
as $$
declare
  new_keywords text[];
  candidate_keywords text[];
  new_title_keywords text[];
  candidate_title_keywords text[];
  new_description_keywords text[];
  candidate_description_keywords text[];
  new_location_keywords text[];
  candidate_location_keywords text[];
  color_words text[] := array['black', 'white', 'red', 'blue', 'green', 'yellow', 'orange', 'purple', 'pink', 'brown', 'grey', 'gray', 'silver', 'gold', 'golden', 'beige', 'cream', 'maroon', 'navy', 'transparent'];
  title_shared_count integer;
  shared_count integer;
  union_count integer;
  description_shared_count integer;
  description_union_count integer;
  location_shared_count integer;
  color_shared_count integer;
  core_evidence_count integer;
  day_diff integer;
begin
  score := 0;
  reasons := '{}';

  if new_item.category is distinct from candidate.category then
    return next;
  end if;

  -- Core item similarity intentionally excludes location and category.
  -- Those fields are supporting evidence only and cannot create a match alone.
  new_keywords := findit_keywords(new_item.title, new_item.description, '', '', new_item.keywords);
  candidate_keywords := findit_keywords(candidate.title, candidate.description, '', '', candidate.keywords);
  new_title_keywords := findit_keywords(new_item.title, '', '', '', '{}'::text[]);
  candidate_title_keywords := findit_keywords(candidate.title, '', '', '', '{}'::text[]);
  new_description_keywords := findit_keywords('', new_item.description, '', '', '{}'::text[]);
  candidate_description_keywords := findit_keywords('', candidate.description, '', '', '{}'::text[]);
  new_location_keywords := findit_keywords('', '', new_item.location, '', '{}'::text[]);
  candidate_location_keywords := findit_keywords('', '', candidate.location, '', '{}'::text[]);

  score := score + 10;
  reasons := array_append(reasons, 'same category');

  select count(*) into title_shared_count
  from unnest(new_title_keywords) token
  where token = any(candidate_title_keywords);

  if title_shared_count > 0 then
    score := score + least(30, title_shared_count * 15);
    reasons := array_append(reasons, 'similar title');
  end if;

  select count(*) into shared_count
  from unnest(new_keywords) token
  where token = any(candidate_keywords);

  select count(distinct token) into union_count
  from (
    select unnest(new_keywords) as token
    union
    select unnest(candidate_keywords) as token
  ) all_tokens;

  if union_count > 0 and (shared_count::numeric / union_count::numeric) >= 0.25 then
    score := score + least(25, greatest(shared_count * 8, round((shared_count::numeric / union_count::numeric) * 35)::integer));
    reasons := array_append(reasons, 'matched keywords');
  elsif shared_count >= 2 then
    score := score + least(25, shared_count * 8);
    reasons := array_append(reasons, 'matched keywords');
  end if;

  select count(*) into description_shared_count
  from unnest(new_description_keywords) token
  where token = any(candidate_description_keywords);

  select count(distinct token) into description_union_count
  from (
    select unnest(new_description_keywords) as token
    union
    select unnest(candidate_description_keywords) as token
  ) all_description_tokens;

  if description_shared_count >= 2
    or (description_union_count > 0 and (description_shared_count::numeric / description_union_count::numeric) >= 0.35) then
    score := score + least(15, greatest(description_shared_count * 5, round((description_shared_count::numeric / greatest(description_union_count, 1)::numeric) * 20)::integer));
    reasons := array_append(reasons, 'similar description');
  end if;

  select count(*) into color_shared_count
  from unnest(new_keywords) token
  where token = any(color_words)
    and token = any(candidate_keywords);

  if color_shared_count > 0 then
    score := score + 8;
    reasons := array_append(reasons, 'same color');
  end if;

  core_evidence_count :=
    case when title_shared_count > 0 then 1 else 0 end +
    case when shared_count >= 2 or (union_count > 0 and (shared_count::numeric / union_count::numeric) >= 0.30) then 1 else 0 end +
    case when description_shared_count >= 2 or (description_union_count > 0 and (description_shared_count::numeric / description_union_count::numeric) >= 0.35) then 1 else 0 end +
    case when color_shared_count > 0 then 1 else 0 end;

  if core_evidence_count < 2 then
    score := 0;
    reasons := '{}';
    return next;
  end if;

  select count(*) into location_shared_count
  from unnest(new_location_keywords) token
  where token = any(candidate_location_keywords);

  if location_shared_count > 0 then
    score := score + 5;
    reasons := array_append(reasons, 'similar location');
  end if;

  if new_item.item_date is not null and candidate.item_date is not null then
    day_diff := abs(new_item.item_date - candidate.item_date);
    if day_diff = 0 then
      score := score + 5;
      reasons := array_append(reasons, 'same date');
    elsif day_diff <= 2 then
      score := score + 3;
      reasons := array_append(reasons, 'nearby date');
    end if;
  end if;

  if new_item.photo_url is not null and candidate.photo_url is not null and new_item.category = candidate.category then
    score := score + 7;
    reasons := array_append(reasons, 'photos available for review');
  end if;

  score := least(score, 100);
  return next;
end;
$$;

-- Match notification trigger
create or replace function findit_create_match_notifications()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  candidate items%rowtype;
  match_result record;
  key text;
  lost_id uuid;
  found_id uuid;
begin
  if new.status = 'resolved' then
    return new;
  end if;

  for candidate in
    select *
    from items
    where id <> new.id
      and type <> new.type
      and status <> 'resolved'
  loop
    select * into match_result from findit_match_score(new, candidate);

    if match_result.score >= 70 then
      key := least(new.id::text, candidate.id::text) || ':' || greatest(new.id::text, candidate.id::text);
      lost_id := case when new.type = 'lost' then new.id else candidate.id end;
      found_id := case when new.type = 'found' then new.id else candidate.id end;

      insert into item_matches(match_key, lost_item_id, found_item_id, score, reasons)
      values (key, lost_id, found_id, match_result.score, match_result.reasons)
      on conflict (match_key) do nothing;

      insert into notifications(user_id, item_id, matched_item_id, type, message, match_key)
      values (
        new.reporter_id,
        candidate.id,
        new.id,
        'match',
        'Possible match found: "' || coalesce(candidate.title, 'another report') || '" looks similar to your ' || new.type || ' report. ' || match_result.score || '% match.',
        key
      )
      on conflict do nothing;

      insert into notifications(user_id, item_id, matched_item_id, type, message, match_key)
      values (
        candidate.reporter_id,
        new.id,
        candidate.id,
        'match',
        'Possible match found: "' || coalesce(new.title, 'another report') || '" looks similar to your ' || candidate.type || ' report. ' || match_result.score || '% match.',
        key
      )
      on conflict do nothing;
    end if;
  end loop;

  return new;
end;
$$;

drop trigger if exists findit_match_notifications_after_item_insert on items;

create trigger findit_match_notifications_after_item_insert
after insert on items
for each row
execute function findit_create_match_notifications();

-- Approved-contact function: phone-only contact, visible only to item owner or approved claimant.
drop function if exists findit_get_item_contacts(uuid);

create function findit_get_item_contacts(target_item_id uuid)
returns table (
  user_id uuid,
  full_name text,
  phone text,
  alternate_contact text,
  relation text
)
language sql
security definer
set search_path = public
as $$
  with target_item as (
    select *
    from items
    where id = target_item_id
  ),
  approved_claims as (
    select *
    from claims
    where item_id = target_item_id
      and status = 'approved'
  ),
  allowed as (
    select ti.reporter_id as contact_user_id, 'reporter'::text as relation
    from target_item ti
    where auth.uid() = ti.reporter_id
       or exists (
         select 1
         from approved_claims ac
         where ac.requester_id = auth.uid()
       )
    union
    select ac.requester_id as contact_user_id, 'approved_claimant'::text as relation
    from approved_claims ac
    join target_item ti on true
    where auth.uid() = ti.reporter_id
       or auth.uid() = ac.requester_id
  )
  select
    p.id as user_id,
    p.full_name,
    p.phone,
    p.alternate_contact,
    allowed.relation
  from allowed
  join profiles p on p.id = allowed.contact_user_id;
$$;

-- Storage policies
drop policy if exists "logged in users can upload item photos" on storage.objects;
drop policy if exists "item photos are publicly readable" on storage.objects;

create policy "logged in users can upload item photos"
on storage.objects for insert
to authenticated
with check (bucket_id = 'item-photos');

create policy "item photos are publicly readable"
on storage.objects for select
using (bucket_id = 'item-photos');

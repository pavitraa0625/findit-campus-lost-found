alter table items
add column if not exists keywords text[] default '{}';

alter table notifications
add column if not exists match_key text,
add column if not exists matched_item_id uuid references items(id) on delete set null;

alter table profiles
add column if not exists phone text,
add column if not exists alternate_contact text;

update profiles
set roll_number = 'BL.EN.' || upper((regexp_match(coalesce(roll_number, email, ''), 'u[0-9][a-z]+[0-9]*', 'i'))[1])
where coalesce(roll_number, email, '') ~* 'u[0-9][a-z]+[0-9]*'
  and coalesce(roll_number, '') !~* '^BL\.EN\.';

create table if not exists item_matches (
  id uuid primary key default gen_random_uuid(),
  match_key text not null unique,
  lost_item_id uuid not null references items(id) on delete cascade,
  found_item_id uuid not null references items(id) on delete cascade,
  score integer not null default 0,
  reasons text[] not null default '{}',
  created_at timestamptz not null default now()
);

create unique index if not exists notifications_user_match_unique
on notifications(user_id, type, match_key)
where match_key is not null;

alter table items replica identity full;
alter table claims replica identity full;
alter table notifications replica identity full;

do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    if not exists (
      select 1 from pg_publication_tables
      where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'items'
    ) then
      alter publication supabase_realtime add table items;
    end if;

    if not exists (
      select 1 from pg_publication_tables
      where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'claims'
    ) then
      alter publication supabase_realtime add table claims;
    end if;

    if not exists (
      select 1 from pg_publication_tables
      where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'notifications'
    ) then
      alter publication supabase_realtime add table notifications;
    end if;
  end if;
end $$;

create or replace function findit_keywords(
  title text,
  description text,
  location text,
  category text,
  keywords text[]
) returns text[]
language sql
immutable
as $$
  select array(
    select distinct token
    from regexp_split_to_table(
      lower(coalesce(title, '') || ' ' || coalesce(description, '') || ' ' || coalesce(location, '') || ' ' || coalesce(category, '') || ' ' || array_to_string(coalesce(keywords, '{}'), ' ')),
      '[^a-z0-9]+'
    ) as token
    where length(token) > 2
      and token not in ('the', 'and', 'for', 'with', 'near', 'from', 'this', 'that', 'item', 'lost', 'found', 'please', 'kindly')
  );
$$;

create or replace function findit_match_score(new_item items, candidate items)
returns table(score integer, reasons text[])
language plpgsql
stable
as $$
declare
  new_keywords text[];
  candidate_keywords text[];
  new_title_keywords text[];
  candidate_title_keywords text[];
  title_shared_count integer;
  shared_count integer;
  union_count integer;
  day_diff integer;
begin
  score := 0;
  reasons := '{}';

  if new_item.category is distinct from candidate.category then
    return next;
  end if;

  new_keywords := findit_keywords(new_item.title, new_item.description, new_item.location, new_item.category, new_item.keywords);
  candidate_keywords := findit_keywords(candidate.title, candidate.description, candidate.location, candidate.category, candidate.keywords);
  new_title_keywords := findit_keywords(new_item.title, '', '', '', '{}');
  candidate_title_keywords := findit_keywords(candidate.title, '', '', '', '{}');

  score := score + 25;
  reasons := array_append(reasons, 'same category');

  select count(*) into title_shared_count
  from unnest(new_title_keywords) token
  where token = any(candidate_title_keywords);

  if title_shared_count > 0 then
    score := score + least(35, title_shared_count * 18);
    reasons := array_append(reasons, 'similar title');
  end if;

  select count(*) into shared_count
  from unnest(new_keywords) token
  where token = any(candidate_keywords);

  select count(distinct token) into union_count
  from (
    select unnest(new_keywords) as token
    union
    select unnest(candidate_keywords) as token
  ) all_tokens;

  if shared_count >= 2 then
    score := score + least(30, shared_count * 8);
    reasons := array_append(reasons, 'shared keywords');
  end if;

  if union_count > 0 and (shared_count::numeric / union_count::numeric) >= 0.25 then
    score := score + 15;
    reasons := array_append(reasons, 'similar details');
  end if;

  if title_shared_count = 0 and shared_count < 2 and not (union_count > 0 and (shared_count::numeric / union_count::numeric) >= 0.25) then
    score := 0;
    reasons := '{}';
    return next;
  end if;

  if new_item.location is not null
    and candidate.location is not null
    and lower(candidate.location) like '%' || split_part(lower(new_item.location), ' ', 1) || '%' then
    score := score + 8;
    reasons := array_append(reasons, 'similar location');
  end if;

  if new_item.item_date is not null and candidate.item_date is not null then
    day_diff := abs(new_item.item_date - candidate.item_date);
    if day_diff = 0 then
      score := score + 7;
      reasons := array_append(reasons, 'same date');
    elsif day_diff <= 2 then
      score := score + 4;
      reasons := array_append(reasons, 'nearby date');
    end if;
  end if;

  if new_item.photo_url is not null and candidate.photo_url is not null and new_item.category = candidate.category then
    score := score + 5;
    reasons := array_append(reasons, 'photos available');
  end if;

  score := least(score, 100);
  return next;
end;
$$;

create or replace function findit_create_match_notifications()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  candidate items%rowtype;
  match_result record;
  key text;
  lost_id uuid;
  found_id uuid;
begin
  if new.status = 'resolved' then
    return new;
  end if;

  for candidate in
    select *
    from items
    where id <> new.id
      and type <> new.type
      and status <> 'resolved'
  loop
    select * into match_result from findit_match_score(new, candidate);

    if match_result.score >= 60 then
      key := least(new.id::text, candidate.id::text) || ':' || greatest(new.id::text, candidate.id::text);
      lost_id := case when new.type = 'lost' then new.id else candidate.id end;
      found_id := case when new.type = 'found' then new.id else candidate.id end;

      insert into item_matches(match_key, lost_item_id, found_item_id, score, reasons)
      values (key, lost_id, found_id, match_result.score, match_result.reasons)
      on conflict (match_key) do nothing;

      insert into notifications(user_id, item_id, matched_item_id, type, message, match_key)
      values (
        new.reporter_id,
        candidate.id,
        new.id,
        'match',
        'Possible match found: "' || coalesce(candidate.title, 'another report') || '" looks similar to your ' || new.type || ' report. ' || match_result.score || '% match.',
        key
      )
      on conflict do nothing;

      insert into notifications(user_id, item_id, matched_item_id, type, message, match_key)
      values (
        candidate.reporter_id,
        new.id,
        candidate.id,
        'match',
        'Possible match found: "' || coalesce(new.title, 'another report') || '" looks similar to your ' || candidate.type || ' report. ' || match_result.score || '% match.',
        key
      )
      on conflict do nothing;
    end if;
  end loop;

  return new;
end;
$$;

drop trigger if exists findit_match_notifications_after_item_insert on items;

create trigger findit_match_notifications_after_item_insert
after insert on items
for each row
execute function findit_create_match_notifications();

drop function if exists findit_get_item_contacts(uuid);

create function findit_get_item_contacts(target_item_id uuid)
returns table (
  user_id uuid,
  full_name text,
  phone text,
  alternate_contact text,
  relation text
)
language sql
security definer
set search_path = public
as $$
  with target_item as (
    select *
    from items
    where id = target_item_id
  ),
  approved_claims as (
    select *
    from claims
    where item_id = target_item_id
      and status = 'approved'
  ),
  allowed as (
    select ti.reporter_id as contact_user_id, 'reporter'::text as relation
    from target_item ti
    where auth.uid() = ti.reporter_id
       or exists (
         select 1
         from approved_claims ac
         where ac.requester_id = auth.uid()
       )
    union
    select ac.requester_id as contact_user_id, 'approved_claimant'::text as relation
    from approved_claims ac
    join target_item ti on true
    where auth.uid() = ti.reporter_id
       or auth.uid() = ac.requester_id
  )
  select
    p.id as user_id,
    p.full_name,
    p.phone,
    p.alternate_contact,
    allowed.relation
  from allowed
  join profiles p on p.id = allowed.contact_user_id;
$$;

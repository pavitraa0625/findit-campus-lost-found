$ErrorActionPreference = "Stop"

$projectDir = Split-Path -Parent $MyInvocation.MyCommand.Path

Set-Location $projectDir
Write-Host "Starting FindIt at http://127.0.0.1:5500/index.html"
Write-Host "Keep this window open while testing. Press Ctrl+C to stop."

$node = (Get-Command node -ErrorAction SilentlyContinue).Source
if ($node) {
  $nodeScript = @'
const http = require('http');
const fs = require('fs');
const path = require('path');
const root = process.cwd();
const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.sql': 'text/plain' };
http.createServer((req, res) => {
  let urlPath = decodeURIComponent(req.url.split('?')[0]);
  const hasVersion = req.url.includes('v=20260516b');
  if (urlPath === '/report.html' && !hasVersion) {
    res.writeHead(302, {
      'Location': '/report.html?v=20260516b',
      'Cache-Control': 'no-store, max-age=0'
    });
    res.end();
    return;
  }
  if (urlPath === '/') urlPath = '/index.html';
  const filePath = path.join(root, urlPath);
  if (!filePath.startsWith(root)) {
    res.writeHead(403);
    res.end('Forbidden');
    return;
  }
  fs.readFile(filePath, (error, data) => {
    if (error) {
      res.writeHead(404);
      res.end('Not found');
      return;
    }
    res.writeHead(200, {
      'Content-Type': types[path.extname(filePath)] || 'application/octet-stream',
      'Cache-Control': 'no-store, max-age=0'
    });
    res.end(data);
  });
}).listen(5500, '127.0.0.1');
'@

  & $node -e $nodeScript
  exit
}

$bundledPython = "C:\Users\Meghana\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
$python = if (Test-Path $bundledPython) { $bundledPython } else { (Get-Command python -ErrorAction SilentlyContinue).Source }

if ($python) {
  & $python -m http.server 5500 --bind 127.0.0.1
  exit
}

throw "Neither Python nor Node.js was found. Install one of them to run the local server."

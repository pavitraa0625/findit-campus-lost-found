alter table profiles
add column if not exists email text unique;

create policy "authenticated users can create notifications"
on notifications for insert
to authenticated
with check (true);

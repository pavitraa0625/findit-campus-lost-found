-- FindIt linked lost/found return synchronization upgrade
-- Paste this whole file into Supabase SQL Editor and run it once.

alter table claims
add column if not exists matched_item_id uuid references items(id) on delete set null,
add column if not exists return_lost_confirmed_at timestamptz,
add column if not exists return_found_confirmed_at timestamptz,
add column if not exists return_completed_at timestamptz;

alter table claims
drop constraint if exists claims_status_check;

alter table claims
add constraint claims_status_check
check (status in ('pending', 'approved', 'rejected', 'completed'));

create index if not exists claims_matched_item_id_idx on claims(matched_item_id);

drop policy if exists "users can view related claims" on claims;
drop policy if exists "item owners can update claims" on claims;

create policy "users can view related claims"
on claims for select
to authenticated
using (
  requester_id = auth.uid()
  or exists (
    select 1
    from items
    where items.id = claims.item_id
      and items.reporter_id = auth.uid()
  )
  or exists (
    select 1
    from items
    where items.id = claims.matched_item_id
      and items.reporter_id = auth.uid()
  )
);

create policy "item owners can update claims"
on claims for update
to authenticated
using (
  exists (
    select 1
    from items
    where items.id = claims.item_id
      and items.reporter_id = auth.uid()
  )
  or exists (
    select 1
    from items
    where items.id = claims.matched_item_id
      and items.reporter_id = auth.uid()
  )
);

update claims
set return_lost_confirmed_at = case
    when return_lost_confirmed_at is not null then return_lost_confirmed_at
    when exists (select 1 from items where items.id = claims.item_id and items.type = 'lost') then return_owner_confirmed_at
    else return_requester_confirmed_at
  end,
  return_found_confirmed_at = case
    when return_found_confirmed_at is not null then return_found_confirmed_at
    when exists (select 1 from items where items.id = claims.item_id and items.type = 'found') then return_owner_confirmed_at
    else return_requester_confirmed_at
  end
where status in ('approved', 'completed');

update claims
set status = 'completed',
    return_completed_at = coalesce(return_completed_at, return_confirmed_at, now())
where return_lost_confirmed_at is not null
  and return_found_confirmed_at is not null
  and status = 'approved';

let currentUser = null;

const APP_VERSION = '20260518b';

window.addEventListener('pageshow', event => {
  if (event.persisted) {
    location.reload();
  }
});

function patchLegacyReportForm() {
  if (!location.pathname.endsWith('/report.html')) return;
  const oldContactInput = document.getElementById('f-contact');
  const oldPrivacySelect = document.getElementById('f-privacy');
  if (!oldContactInput && !oldPrivacySelect) return;

  const oldCard = oldContactInput?.closest('.card') || oldPrivacySelect?.closest('.card');
  if (!oldCard) return;

  oldCard.innerHTML = `
    <div class="card-header">Reporter</div>
    <div class="card-body">
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Your Name</label>
          <input class="form-input" id="f-name" placeholder="Full name" disabled>
        </div>
        <div class="form-group">
          <label class="form-label">Roll Number</label>
          <input class="form-input" id="f-roll" placeholder="Roll number" disabled>
        </div>
      </div>
      <p style="font-size:12px;color:#777;">Phone number is saved in your profile and shown only after claim approval. <a href="profile.html?next=report.html%3Fv%3D${APP_VERSION}" style="color:#c2185b;">Update phone</a></p>
    </div>`;

  if (currentUser) {
    const nameEl = document.getElementById('f-name');
    const rollEl = document.getElementById('f-roll');
    if (nameEl) nameEl.value = currentUser.name || '';
    if (rollEl) rollEl.value = normalizeRollNumber(currentUser.roll, currentUser.email);
  }
}

document.addEventListener('DOMContentLoaded', patchLegacyReportForm);

function uid(prefix) {
  return prefix + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function isUuid(value) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value || '');
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[char]));
}

function escapeAttr(value) {
  return escapeHtml(value).replace(/`/g, '&#96;');
}

function normalizeRollNumber(value, email) {
  const raw = String(value || '').trim();
  const source = `${raw} ${String(email || '').split('@')[0]}`;
  const match = source.match(/u\d[a-z]+\d*/i);
  if (match) return `BL.EN.${match[0].toUpperCase()}`;
  if (/^bl\.en/i.test(raw)) return raw.toUpperCase();
  return raw.toUpperCase();
}

function getUser() {
  return currentUser;
}

async function requireLogin() {
  const user = await loadCurrentUser();
  if (!user || !user.loggedIn) {
    location.href = 'index.html';
    return null;
  }
  return user;
}

async function loadCurrentUser() {
  const { data, error } = await supabaseClient.auth.getUser();
  if (error || !data.user) return null;

  let profile = null;
  const { data: profileData } = await supabaseClient
    .from('profiles')
    .select('*')
    .eq('id', data.user.id)
    .maybeSingle();

  profile = profileData;
  currentUser = {
    loggedIn: true,
    id: data.user.id,
    email: data.user.email,
    name: profile?.full_name || data.user.user_metadata?.full_name || 'FindIt User',
    roll: normalizeRollNumber(profile?.roll_number || data.user.user_metadata?.roll_number || '', data.user.email),
    role: profile?.role || data.user.user_metadata?.role || 'student',
    phone: profile?.phone || '',
    alternateContact: profile?.alternate_contact || '',
    contactComplete: !!profile?.phone
  };
  return currentUser;
}

async function saveCurrentUserContact(contact) {
  if (!currentUser?.id) return null;
  const row = {
    id: currentUser.id,
    email: currentUser.email,
    full_name: currentUser.name,
    roll_number: normalizeRollNumber(currentUser.roll, currentUser.email),
    role: currentUser.role || 'student',
    phone: contact.phone || '',
    alternate_contact: contact.alternateContact || ''
  };
  const { error } = await supabaseClient.from('profiles').upsert(row);
  if (error) throw error;
  return loadCurrentUser();
}

async function renderTopbarUser(containerId) {
  const u = getUser() || await loadCurrentUser();
  const el = document.getElementById(containerId);
  if (!el) return;
  if (u && u.loggedIn) {
    await DB.loadAll();
    const unread = DB.getUnreadNotifications(u.email).length;
    el.innerHTML = `
      <span class="topbar-user">${escapeHtml(u.name || 'FindIt User')}</span>
      <a href="notifications.html" style="color:white;font-size:12px;text-decoration:none;">Notifications${unread ? ' (' + unread + ')' : ''}</a>
      <a href="index.html" onclick="doLogout(event)" style="color:white;font-size:12px;text-decoration:none;opacity:0.8;">Sign Out</a>`;
  } else {
    el.innerHTML = `<a href="index.html" style="color:white;font-size:12px;">Sign In</a>`;
  }
}

async function doLogout(e) {
  if (e) e.preventDefault();
  sessionStorage.removeItem('findit_admin_session_started');
  sessionStorage.removeItem('findit_admin_session_seen');
  sessionStorage.removeItem('findit_admin_session_only');
  await supabaseClient.auth.signOut();
  currentUser = null;
  location.href = 'index.html';
}

function normalizeItem(row, profile, claims) {
  const itemClaims = claims || [];
  const approvedClaim = itemClaims.find(c => c.status === 'approved');
  const pendingClaim = itemClaims.find(c => c.status === 'pending');
  const photoUrls = Array.isArray(row.photo_urls) ? row.photo_urls : [];
  return {
    id: row.id || uid('item_'),
    type: row.type || 'lost',
    title: row.title || '',
    category: row.category || 'other',
    keywords: Array.isArray(row.keywords) ? row.keywords : [],
    date: row.item_date || row.date || '',
    location: row.location || '',
    description: row.description || '',
    emoji: categoryEmoji(row.category || 'other'),
    reporterId: row.reporter_id || row.reporterId || null,
    reporterName: profile?.full_name || row.reporterName || '',
    reporterEmail: profile?.email || row.reporterEmail || '',
    reporterRoll: normalizeRollNumber(profile?.roll_number || row.reporterRoll || '', profile?.email || row.reporterEmail),
    reporterRole: profile?.role || row.reporterRole || 'student',
    reporterPhone: '',
    reporterAlternateContact: '',
    contact: '',
    contactVisible: row.contact_privacy === 'visible',
    contactPrivacy: row.contact_privacy || row.contactPrivacy || 'claim-only',
    photo: row.photo_url || photoUrls[0] || row.photo || null,
    photos: photoUrls.length ? photoUrls : (row.photo_url ? [row.photo_url] : []),
    status: row.status || 'open',
    moderationStatus: row.moderation_status || 'active',
    resolutionSource: row.resolution_source || 'user',
    createdAt: row.created_at || row.createdAt || new Date().toISOString(),
    updatedAt: row.updated_at || row.updatedAt || row.created_at || new Date().toISOString(),
    claimStatus: approvedClaim ? 'approved' : pendingClaim ? 'pending' : 'none',
    claimedBy: approvedClaim?.requesterEmail || null,
    claimRequestId: pendingClaim?.id || approvedClaim?.id || null,
    resolvedAt: row.resolved_at || row.resolvedAt || null,
    resolutionNote: '',
    adminPosted: profile?.role === 'admin',
    views: []
  };
}

function normalizeClaim(row, profile) {
  return {
    id: row.id,
    itemId: row.item_id,
    matchedItemId: row.matched_item_id || null,
    requesterId: row.requester_id,
    requesterEmail: profile?.email || row.requester_email || row.requester_id,
    requesterName: profile?.full_name || row.requesterName || 'FindIt User',
    requesterRoll: normalizeRollNumber(profile?.roll_number || row.requesterRoll || '', profile?.email || row.requester_email),
    requesterPhone: '',
    requesterAlternateContact: '',
    message: row.message || '',
    matchKey: row.match_key || row.matchKey || '',
    status: row.status || 'pending',
    returnInitiatedBy: row.return_initiated_by || null,
    returnInitiatedAt: row.return_initiated_at || null,
    returnOwnerConfirmedAt: row.return_owner_confirmed_at || null,
    returnRequesterConfirmedAt: row.return_requester_confirmed_at || null,
    returnLostConfirmedAt: row.return_lost_confirmed_at || null,
    returnFoundConfirmedAt: row.return_found_confirmed_at || null,
    returnConfirmedAt: row.return_confirmed_at || null,
    returnCompletedAt: row.return_completed_at || null,
    createdAt: row.created_at,
    updatedAt: row.updated_at || row.created_at
  };
}

function normalizeNotification(row) {
  return {
    id: row.id,
    userId: row.user_id,
    itemId: row.item_id,
    matchedItemId: row.matched_item_id || row.matchedItemId || null,
    type: row.type || 'info',
    message: row.message || '',
    matchKey: row.match_key || row.matchKey || '',
    read: !!row.read,
    createdAt: row.created_at
  };
}

async function getProfilesByIds(ids) {
  const uniqueIds = [...new Set(ids.filter(Boolean))];
  if (!uniqueIds.length) return new Map();
  const { data, error } = await supabaseClient
    .from('profiles')
    .select('id,email,full_name,roll_number,role')
    .in('id', uniqueIds);
  if (error) throw error;
  return new Map((data || []).map(profile => [profile.id, profile]));
}

async function getProfileByEmail(email) {
  if (!email) return null;
  if (isUuid(email)) {
    const { data } = await supabaseClient.from('profiles').select('*').eq('id', email).maybeSingle();
    return data;
  }
  const { data } = await supabaseClient.from('profiles').select('*').eq('email', email).maybeSingle();
  return data;
}

function toItemRow(item, user) {
  const photos = item.photos || (item.photo ? [item.photo] : []);
  return {
    type: item.type,
    title: item.title,
    category: item.category,
    item_date: item.date,
    location: item.location,
    description: item.description,
    keywords: item.keywords || getItemKeywords(item),
    photo_url: photos[0] || item.photo || null,
    photo_urls: photos,
    status: item.status || 'open',
    moderation_status: item.moderationStatus || 'active',
    resolution_source: item.resolutionSource || 'user',
    resolved_at: item.resolvedAt || null,
    reporter_id: item.reporterId || user?.id,
    contact: user?.phone || '',
    contact_privacy: 'claim-only',
    updated_at: new Date().toISOString()
  };
}

function stripOptionalItemColumns(row) {
  delete row.keywords;
  delete row.moderation_status;
  delete row.resolution_source;
  delete row.resolved_at;
  return row;
}

const DB = {
  items: [],
  claims: [],
  notifications: [],
  contactAccess: {},
  loaded: false,
  realtimeChannel: null,

  async loadAll(force = false) {
    if (this.loaded && !force) return;
    const { data: itemsData, error: itemsError } = await supabaseClient
      .from('items')
      .select('*')
      .order('created_at', { ascending: false });
    if (itemsError) throw itemsError;

    const { data: claimsData, error: claimsError } = await supabaseClient
      .from('claims')
      .select('*')
      .order('created_at', { ascending: false });
    if (claimsError) throw claimsError;

    const { data: notificationsData, error: notificationsError } = await supabaseClient
      .from('notifications')
      .select('*')
      .order('created_at', { ascending: false });
    if (notificationsError) throw notificationsError;

    const profileIds = [
      ...(itemsData || []).map(item => item.reporter_id),
      ...(claimsData || []).map(claim => claim.requester_id)
    ];
    const profiles = await getProfilesByIds(profileIds);

    this.claims = (claimsData || []).map(claim => normalizeClaim(claim, profiles.get(claim.requester_id)));
    this.items = (itemsData || []).map(item => {
      const itemClaims = this.claims.filter(claim => claim.itemId === item.id);
      return normalizeItem(item, profiles.get(item.reporter_id), itemClaims);
    });
    this.notifications = (notificationsData || []).map(normalizeNotification);
    this.loaded = true;
  },

  getItems() {
    return this.items;
  },
  getActiveItems() {
    return this.items.filter(i => i.status !== 'resolved' && i.moderationStatus !== 'hidden' && !this.isItemCompleted(i.id));
  },
  getResolvedItems() {
    return this.items.filter(i => i.status === 'resolved' || this.isItemCompleted(i.id));
  },
  getById(id) {
    return this.items.find(i => i.id === id) || null;
  },
  getMyItems(email) {
    return this.items.filter(i => i.reporterEmail === email || i.reporterId === currentUser?.id);
  },
  getClaims() {
    return this.claims;
  },
  getClaimsForItem(itemId) {
    return this.claims.filter(c => c.itemId === itemId || c.matchedItemId === itemId);
  },
  getClaimsForUser(email) {
    return this.claims.filter(c => c.requesterEmail === email || c.requesterId === currentUser?.id);
  },
  getApprovedClaimForItem(itemId) {
    return this.claims.find(c => (c.itemId === itemId || c.matchedItemId === itemId) && (c.status === 'approved' || c.status === 'completed')) || null;
  },
  isItemCompleted(itemId) {
    return this.claims.some(c => (c.itemId === itemId || c.matchedItemId === itemId) && (c.status === 'completed' || c.returnCompletedAt));
  },
  getUserNotifications(email) {
    return this.notifications.filter(n => n.userId === currentUser?.id || n.userEmail === email);
  },
  getUnreadNotifications(email) {
    return this.getUserNotifications(email).filter(n => !n.read);
  },
  getContactForUser(itemId, userId) {
    if (!itemId || !userId) return null;
    return (this.contactAccess[itemId] || []).find(contact => contact.user_id === userId) || null;
  },
  async loadContactAccess(itemId) {
    if (!itemId) return [];
    const { data, error } = await supabaseClient.rpc('findit_get_item_contacts', { target_item_id: itemId });
    if (error) {
      console.warn('Approved contacts unavailable:', error.message);
      this.contactAccess[itemId] = [];
      return [];
    }
    this.contactAccess[itemId] = data || [];
    return this.contactAccess[itemId];
  },
  getNotificationDuplicate(userId, type, itemId, matchKey, message) {
    return this.notifications.find(n => {
      if (n.userId !== userId) return false;
      if (matchKey && n.matchKey === matchKey && n.type === type) return true;
      return !matchKey && n.type === type && n.itemId === itemId && n.message === message;
    });
  },

  async uploadPhoto(file) {
    if (!file) return null;
    const ext = (file.name.split('.').pop() || 'jpg').toLowerCase();
    const path = `${currentUser.id}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
    const { error } = await supabaseClient.storage.from('item-photos').upload(path, file, {
      cacheControl: '3600',
      upsert: false
    });
    if (error) throw error;
    const { data } = supabaseClient.storage.from('item-photos').getPublicUrl(path);
    return data.publicUrl;
  },

  async uploadPhotos(files) {
    const selected = Array.from(files || []);
    const uploaded = [];
    for (const file of selected) {
      uploaded.push(await this.uploadPhoto(file));
    }
    return uploaded;
  },

  async addItem(item) {
    if (item.photoFiles?.length) {
      item.photos = await this.uploadPhotos(item.photoFiles);
      item.photo = item.photos[0] || null;
    } else if (item.photoFile) {
      item.photo = await this.uploadPhoto(item.photoFile);
      item.photos = [item.photo];
    }
    const row = toItemRow(item, currentUser);
    let { data, error } = await supabaseClient.from('items').insert(row).select('*').single();
    if (error && /keywords|column/i.test(error.message || '')) {
      stripOptionalItemColumns(row);
      const retry = await supabaseClient.from('items').insert(row).select('*').single();
      data = retry.data;
      error = retry.error;
    }
    if (error) throw error;
    await this.loadAll(true);
    const saved = this.getById(data.id);
    await this.notifyMatchesForItem(saved);
    return saved;
  },

  async updateItem(id, updates) {
    if (updates.photoFiles?.length) {
      updates.photos = await this.uploadPhotos(updates.photoFiles);
      updates.photo = updates.photos[0] || null;
    } else if (updates.photoFile) {
      updates.photo = await this.uploadPhoto(updates.photoFile);
      updates.photos = [updates.photo];
    }
    const row = toItemRow({ ...this.getById(id), ...updates }, currentUser);
    delete row.reporter_id;
    let { data, error } = await supabaseClient.from('items').update(row).eq('id', id).select('*').single();
    if (error && /keywords|column/i.test(error.message || '')) {
      stripOptionalItemColumns(row);
      const retry = await supabaseClient.from('items').update(row).eq('id', id).select('*').single();
      data = retry.data;
      error = retry.error;
    }
    if (error) throw error;
    await this.loadAll(true);
    return this.getById(data.id);
  },

  async deleteItem(id) {
    const { error } = await supabaseClient.from('items').delete().eq('id', id);
    if (error) throw error;
    await this.loadAll(true);
  },

  async addClaim(data) {
    const row = {
      item_id: data.itemId,
      matched_item_id: data.matchedItemId || null,
      requester_id: currentUser.id,
      message: data.message || '',
      status: 'pending'
    };
    let { data: claim, error } = await supabaseClient.from('claims').insert(row).select('*').single();
    if (error && /matched_item_id|column/i.test(error.message || '')) {
      delete row.matched_item_id;
      const retry = await supabaseClient.from('claims').insert(row).select('*').single();
      claim = retry.data;
      error = retry.error;
    }
    if (error) throw error;
    await this.loadAll(true);
    return this.claims.find(c => c.id === claim.id);
  },

  async updateClaim(id, updates) {
    const buildRow = (includeLinkedFields = true) => {
      const row = { updated_at: new Date().toISOString() };
      if ('status' in updates) row.status = updates.status;
      if (includeLinkedFields && 'matchedItemId' in updates) row.matched_item_id = updates.matchedItemId;
      if ('returnInitiatedBy' in updates) row.return_initiated_by = updates.returnInitiatedBy;
      if ('returnInitiatedAt' in updates) row.return_initiated_at = updates.returnInitiatedAt;
      if ('returnOwnerConfirmedAt' in updates) row.return_owner_confirmed_at = updates.returnOwnerConfirmedAt;
      if ('returnRequesterConfirmedAt' in updates) row.return_requester_confirmed_at = updates.returnRequesterConfirmedAt;
      if (includeLinkedFields && 'returnLostConfirmedAt' in updates) row.return_lost_confirmed_at = updates.returnLostConfirmedAt;
      if (includeLinkedFields && 'returnFoundConfirmedAt' in updates) row.return_found_confirmed_at = updates.returnFoundConfirmedAt;
      if ('returnConfirmedAt' in updates) row.return_confirmed_at = updates.returnConfirmedAt;
      if (includeLinkedFields && 'returnCompletedAt' in updates) row.return_completed_at = updates.returnCompletedAt;
      return row;
    };
    let row = buildRow(true);
    let { data, error } = await supabaseClient.from('claims').update(row).eq('id', id).select('*').single();
    if (error && /matched_item_id|return_lost_confirmed_at|return_found_confirmed_at|return_completed_at|column|claims_status_check/i.test(error.message || '')) {
      const fallbackUpdates = { ...updates };
      if (fallbackUpdates.status === 'completed') fallbackUpdates.status = 'approved';
      updates = fallbackUpdates;
      row = buildRow(false);
      const retry = await supabaseClient.from('claims').update(row).eq('id', id).select('*').single();
      data = retry.data;
      error = retry.error;
    }
    if (error) throw error;
    await this.loadAll(true);
    return this.claims.find(c => c.id === data.id);
  },

  async addNotification(notification) {
    let userId = notification.userId || null;
    if (!userId) {
      const profile = await getProfileByEmail(notification.userEmail);
      userId = profile?.id || null;
    }
    if (!userId) return null;
    const itemId = notification.itemId || null;
    const matchedItemId = notification.matchedItemId || null;
    const type = notification.type || 'info';
    const message = notification.message || '';
    const matchKey = notification.matchKey || '';
    if (this.getNotificationDuplicate(userId, type, itemId, matchKey, message)) return null;
    const row = {
      user_id: userId,
      item_id: itemId,
      matched_item_id: matchedItemId,
      type,
      message,
      match_key: matchKey || null
    };
    let { data, error } = await supabaseClient.from('notifications').insert(row).select('*').single();
    if (error && /match_key|matched_item_id|column/i.test(error.message || '')) {
      delete row.match_key;
      delete row.matched_item_id;
      const retry = await supabaseClient.from('notifications').insert(row).select('*').single();
      data = retry.data;
      error = retry.error;
    }
    if (error) {
      console.warn('Notification skipped:', error.message);
      return null;
    }
    await this.loadAll(true);
    return data;
  },

  async notifyMatchesForItem(item) {
    if (!item) return [];
    const matches = matchItemsFor(item).filter(match => match.match.score >= MATCH_THRESHOLD);
    const sent = [];
    for (const match of matches) {
      const matchKey = getMatchKey(item.id, match.id);
      const details = `${match.match.label} (${match.match.score}): ${match.match.reasons.join(', ') || 'similar details'}`;
      const reporterMessage = `Possible match found: "${match.title || 'another report'}" looks similar to your ${item.type} report. ${details}.`;
      const matchedReporterMessage = `Possible match found: "${item.title || 'another report'}" looks similar to your ${match.type} report. ${details}.`;
      sent.push(await this.addNotification({
        userId: item.reporterId,
        userEmail: item.reporterEmail,
        type: 'match',
        itemId: match.id,
        matchedItemId: item.id,
        matchKey,
        message: reporterMessage
      }));
      sent.push(await this.addNotification({
        userId: match.reporterId,
        userEmail: match.reporterEmail,
        type: 'match',
        itemId: item.id,
        matchedItemId: match.id,
        matchKey,
        message: matchedReporterMessage
      }));
    }
    return sent.filter(Boolean);
  },

  async markNotificationRead(id) {
    const { error } = await supabaseClient.from('notifications').update({ read: true }).eq('id', id);
    if (error) throw error;
    await this.loadAll(true);
  },

  async markAllNotificationsRead() {
    if (!currentUser?.id) return;
    const { error } = await supabaseClient.from('notifications').update({ read: true }).eq('user_id', currentUser.id);
    if (error) throw error;
    await this.loadAll(true);
  },

  async recordView(itemId, viewerEmail) {
    const item = this.getById(itemId);
    if (!item || viewerEmail === item.reporterEmail) return;
    await this.addNotification({
      userEmail: item.reporterEmail,
      type: 'view',
      itemId,
      message: 'Someone viewed your post.'
    });
  },

  async seedIfEmpty() {
    await this.loadAll();
  },

  subscribeRealtime(onChange) {
    if (this.realtimeChannel || !currentUser?.id) return this.realtimeChannel;
    this.realtimeChannel = supabaseClient
      .channel(`findit-sync-${currentUser.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'items' }, async payload => {
        await this.loadAll(true);
        if (payload.eventType === 'INSERT') {
          const item = this.getById(payload.new.id);
          await this.notifyMatchesForItem(item);
        }
        if (onChange) onChange(payload);
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'claims' }, async payload => {
        await this.loadAll(true);
        if (onChange) onChange(payload);
      })
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'notifications',
        filter: `user_id=eq.${currentUser.id}`
      }, async payload => {
        await this.loadAll(true);
        if (payload.eventType === 'INSERT' && payload.new && !payload.new.read) {
          showToast(payload.new.message || 'New notification');
        }
        if (onChange) onChange(payload);
      })
      .subscribe();
    return this.realtimeChannel;
  }
};

function categoryEmoji(category) {
  const map = {
    bags: 'Bag',
    electronics: 'Device',
    stationery: 'Note',
    accessories: 'Accessory',
    documents: 'ID',
    keys: 'Key',
    clothing: 'Cloth',
    other: 'Item'
  };
  return map[category] || 'Item';
}

function canViewerSeeContact(item, viewer, isOwner) {
  if (isOwner) return true;
  const approvedClaim = DB.getClaimsForItem(item.id).find(c => c.status === 'approved' && (c.requesterEmail === viewer?.email || c.requesterId === viewer?.id));
  return !!approvedClaim;
}

function getReturnClaim(item) {
  return DB.getApprovedClaimForItem(item.id);
}

function getClaimItems(claim) {
  if (!claim) return { primaryItem: null, matchedItem: null, inferredItem: null, lostItem: null, foundItem: null, items: [] };
  const primaryItem = DB.getById(claim.itemId);
  const matchedItem = DB.getById(claim.matchedItemId);
  const inferredItem = !matchedItem ? inferMatchedItemForClaim(claim, primaryItem) : null;
  const items = [primaryItem, matchedItem || inferredItem].filter(Boolean);
  return {
    primaryItem,
    matchedItem,
    inferredItem,
    lostItem: items.find(item => item.type === 'lost') || null,
    foundItem: items.find(item => item.type === 'found') || null,
    items
  };
}

function inferMatchedItemForClaim(claim, primaryItem) {
  if (!claim || !primaryItem) return null;
  const oppositeType = primaryItem.type === 'lost' ? 'found' : 'lost';
  const requesterCandidates = DB.getItems().filter(item =>
    item.id !== primaryItem.id &&
    item.type === oppositeType &&
    item.status !== 'resolved' &&
    (item.reporterId === claim.requesterId || item.reporterEmail === claim.requesterEmail)
  );
  const candidates = requesterCandidates.length
    ? requesterCandidates
    : DB.getItems().filter(item => item.id !== primaryItem.id && item.type === oppositeType && item.status !== 'resolved');
  if (!candidates.length) return null;

  const ranked = candidates
    .map(candidate => ({ candidate, match: getMatchInfo(primaryItem, candidate) }))
    .sort((a, b) => b.match.score - a.match.score);
  return ranked[0]?.candidate || candidates[0];
}

function findLinkedPostForClaim(item, viewer) {
  const linkedFromUrl = new URLSearchParams(location.search).get('link');
  const linkedItem = linkedFromUrl ? DB.getById(linkedFromUrl) : null;
  if (linkedItem && linkedItem.type !== item.type && linkedItem.status !== 'resolved') return linkedItem;

  const candidates = DB.getMyItems(viewer?.email || '')
    .filter(candidate => candidate.id !== item.id && candidate.type !== item.type && candidate.status !== 'resolved');
  if (!candidates.length) return null;
  return candidates
    .map(candidate => ({ candidate, match: getMatchInfo(item, candidate) }))
    .sort((a, b) => b.match.score - a.match.score)[0]?.candidate || candidates[0];
}

function getReturnState(item, viewer) {
  const claim = getReturnClaim(item);
  const { primaryItem, matchedItem, lostItem, foundItem, items } = getClaimItems(claim);
  const isOwner = item.reporterId === viewer?.id || item.reporterEmail === viewer?.email;
  const isRequester = !!claim && (claim.requesterId === viewer?.id || claim.requesterEmail === viewer?.email);
  const isLostPerson = (!!lostItem && (lostItem.reporterId === viewer?.id || lostItem.reporterEmail === viewer?.email)) || (isRequester && primaryItem?.type === 'found');
  const isFoundPerson = (!!foundItem && (foundItem.reporterId === viewer?.id || foundItem.reporterEmail === viewer?.email)) || (isRequester && primaryItem?.type === 'lost');
  const ownerConfirmed = !!claim?.returnOwnerConfirmedAt;
  const requesterConfirmed = !!claim?.returnRequesterConfirmedAt;
  const lostConfirmed = !!claim?.returnLostConfirmedAt || (primaryItem?.type === 'lost' ? ownerConfirmed : requesterConfirmed);
  const foundConfirmed = !!claim?.returnFoundConfirmedAt || (primaryItem?.type === 'found' ? ownerConfirmed : requesterConfirmed);
  const started = !!claim?.returnInitiatedAt || items.some(linkedItem => linkedItem.status === 'return_pending');
  const complete = claim?.status === 'completed' || (lostConfirmed && foundConfirmed);
  return {
    claim,
    primaryItem,
    matchedItem,
    lostItem,
    foundItem,
    linkedItems: items,
    isOwner,
    isRequester,
    isLostPerson,
    isFoundPerson,
    ownerConfirmed,
    requesterConfirmed,
    lostConfirmed,
    foundConfirmed,
    started,
    complete
  };
}

function getReturnStatusLabel(item) {
  if (item.status === 'resolved') return 'Resolved';
  const state = getReturnState(item, getUser());
  if (!state.claim) return 'Open';
  if (state.complete) return 'Ready to resolve';
  if (state.lostConfirmed) return 'Waiting for found-person confirmation';
  if (state.foundConfirmed) return 'Waiting for lost-person confirmation';
  if (state.started) return 'Return confirmation pending';
  return 'Approved claim';
}

function getDisplayContact(item, viewer, isOwner) {
  if (!canViewerSeeContact(item, viewer, isOwner)) return 'Visible after claim approval.';
  const contact = isOwner
    ? {
        phone: viewer?.phone || '',
        alternate_contact: viewer?.alternateContact || ''
      }
    : DB.getContactForUser(item.id, item.reporterId);
  const parts = [
    contact?.phone ? `Phone: ${contact.phone}` : '',
    contact?.alternate_contact ? `Alt: ${contact.alternate_contact}` : ''
  ].filter(Boolean);
  return parts.join(' | ') || '-';
}

function matchesQuery(item, query) {
  const q = query.trim().toLowerCase();
  if (!q) return true;
  return [item.title, item.location, item.description, item.reporterName, item.category, ...(item.keywords || [])]
    .filter(Boolean)
    .some(v => v.toLowerCase().includes(q));
}

const MATCH_THRESHOLD = 70;
const MATCH_STOP_WORDS = new Set([
  'the', 'and', 'for', 'with', 'near', 'from', 'this', 'that', 'item', 'lost', 'found',
  'please', 'kindly', 'small', 'large', 'medium', 'short', 'long', 'ones', 'one'
]);
const MATCH_SYNONYMS = new Map(Object.entries({
  cellphone: 'phone',
  mobile: 'phone',
  smartphone: 'phone',
  purse: 'wallet',
  billfold: 'wallet',
  spectacles: 'glasses',
  specs: 'glasses',
  earphones: 'earbuds',
  headphones: 'earbuds',
  charger: 'adapter',
  pendrive: 'usb',
  'idcard': 'id',
  'identity': 'id'
}));
const MATCH_COLORS = new Set([
  'black', 'white', 'red', 'blue', 'green', 'yellow', 'orange', 'purple', 'pink',
  'brown', 'grey', 'gray', 'silver', 'gold', 'golden', 'beige', 'cream', 'maroon',
  'navy', 'transparent'
]);

function tokenizeForMatch(value) {
  return String(value || '')
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .map(normalizeMatchToken)
    .filter(word => word.length > 2 && !MATCH_STOP_WORDS.has(word));
}

function normalizeMatchToken(word) {
  let token = String(word || '').toLowerCase().trim();
  if (!token) return '';
  token = MATCH_SYNONYMS.get(token) || token;
  if (token.endsWith('ies') && token.length > 4) token = token.slice(0, -3) + 'y';
  else if (token.endsWith('es') && token.length > 4) token = token.slice(0, -2);
  else if (token.endsWith('s') && token.length > 3) token = token.slice(0, -1);
  return MATCH_SYNONYMS.get(token) || token;
}

function getItemKeywords(item) {
  return [...new Set([
    ...tokenizeForMatch(item.title),
    ...tokenizeForMatch(item.description),
    ...tokenizeForMatch(item.location),
    ...tokenizeForMatch(item.category),
    ...(Array.isArray(item.keywords) ? item.keywords.flatMap(tokenizeForMatch) : [])
  ])];
}

function getItemDetailKeywords(item) {
  return [...new Set([
    ...tokenizeForMatch(item.title),
    ...tokenizeForMatch(item.description),
    ...(Array.isArray(item.keywords) ? item.keywords.flatMap(tokenizeForMatch) : [])
  ])];
}

function getDescriptionKeywords(item) {
  return [...new Set(tokenizeForMatch(item.description))];
}

function getLocationKeywords(item) {
  return [...new Set(tokenizeForMatch(item.location))];
}

function getColorKeywords(item) {
  return getItemDetailKeywords(item).filter(word => MATCH_COLORS.has(word));
}

function getEditDistance(left, right) {
  if (left === right) return 0;
  if (Math.abs(left.length - right.length) > 2) return 3;
  const dp = Array.from({ length: left.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= right.length; j++) dp[0][j] = j;
  for (let i = 1; i <= left.length; i++) {
    for (let j = 1; j <= right.length; j++) {
      const cost = left[i - 1] === right[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
    }
  }
  return dp[left.length][right.length];
}

function wordsAreSimilar(left, right) {
  if (left === right) return true;
  const minLength = Math.min(left.length, right.length);
  if (minLength < 4) return false;
  const distance = getEditDistance(left, right);
  return distance <= (minLength >= 7 ? 2 : 1);
}

function getTokenSimilarity(leftTokens, rightTokens) {
  const right = [...new Set(rightTokens)];
  const shared = [...new Set(leftTokens)].filter(left => right.some(candidate => wordsAreSimilar(left, candidate)));
  const union = new Set([...leftTokens, ...rightTokens]).size || 1;
  return { shared, ratio: shared.length / union };
}

function getJaccardScore(a, b) {
  const left = new Set(a);
  const right = new Set(b);
  if (!left.size || !right.size) return 0;
  const overlap = [...left].filter(value => right.has(value)).length;
  const union = new Set([...left, ...right]).size;
  return overlap / union;
}

function getMatchKey(leftId, rightId) {
  return [leftId, rightId].filter(Boolean).sort().join(':');
}

function matchItemsFor(item) {
  const oppositeType = item.type === 'lost' ? 'found' : 'lost';
  return DB.getActiveItems().map(candidate => {
    if (candidate.id === item.id || candidate.type !== oppositeType) return false;
    const match = getMatchInfo(item, candidate);
    return match.score >= MATCH_THRESHOLD ? { ...candidate, match } : false;
  }).filter(Boolean).sort((a, b) => b.match.score - a.match.score).slice(0, 4);
}

function getMatchInfo(item, candidate) {
  let score = 0;
  const reasons = [];
  const itemTitleKeywords = tokenizeForMatch(item.title);
  const candidateTitleKeywords = tokenizeForMatch(candidate.title);
  const itemKeywords = getItemDetailKeywords(item);
  const candidateKeywords = getItemDetailKeywords(candidate);
  const itemDescriptionKeywords = getDescriptionKeywords(item);
  const candidateDescriptionKeywords = getDescriptionKeywords(candidate);
  const itemLocationKeywords = getLocationKeywords(item);
  const candidateLocationKeywords = getLocationKeywords(candidate);
  const itemColors = getColorKeywords(item);
  const candidateColors = getColorKeywords(candidate);
  const sameCategory = candidate.category === item.category;
  if (!sameCategory) return { score: 0, label: 'No match', reasons: [] };

  score += 10;
  reasons.push('same category');

  const titleMatch = getTokenSimilarity(itemTitleKeywords, candidateTitleKeywords);
  if (titleMatch.shared.length) {
    score += Math.min(30, Math.max(titleMatch.shared.length * 15, Math.round(titleMatch.ratio * 35)));
    reasons.push(`similar title: ${titleMatch.shared.slice(0, 4).join(', ')}`);
  }

  const keywordMatch = getTokenSimilarity(itemKeywords, candidateKeywords);
  if (keywordMatch.shared.length >= 2 || keywordMatch.ratio >= 0.3) {
    score += Math.min(25, Math.max(keywordMatch.shared.length * 8, Math.round(keywordMatch.ratio * 35)));
    reasons.push(`matched keywords: ${keywordMatch.shared.slice(0, 6).join(', ')}`);
  }

  const descriptionMatch = getTokenSimilarity(itemDescriptionKeywords, candidateDescriptionKeywords);
  if (descriptionMatch.shared.length >= 2 || descriptionMatch.ratio >= 0.35) {
    score += Math.min(15, Math.max(descriptionMatch.shared.length * 5, Math.round(descriptionMatch.ratio * 20)));
    reasons.push(`similar description: ${descriptionMatch.shared.slice(0, 5).join(', ')}`);
  }

  const colorMatch = getTokenSimilarity(itemColors, candidateColors);
  if (colorMatch.shared.length) {
    score += 8;
    reasons.push(`same color: ${colorMatch.shared.slice(0, 3).join(', ')}`);
  }

  const coreEvidenceCount = [
    titleMatch.shared.length > 0,
    keywordMatch.shared.length >= 2 || keywordMatch.ratio >= 0.3,
    descriptionMatch.shared.length >= 2 || descriptionMatch.ratio >= 0.35,
    colorMatch.shared.length > 0
  ].filter(Boolean).length;
  if (coreEvidenceCount < 2) {
    return { score: 0, label: 'No match', reasons: [] };
  }

  const locationMatch = getTokenSimilarity(itemLocationKeywords, candidateLocationKeywords);
  if (locationMatch.shared.length) {
    score += 5;
    reasons.push('similar location');
  }

  if (item.date && candidate.date) {
    const dayDiff = Math.abs((new Date(item.date) - new Date(candidate.date)) / 86400000);
    if (dayDiff === 0) {
      score += 5;
      reasons.push('same date');
    } else if (dayDiff <= 2) {
      score += 3;
      reasons.push('nearby date');
    }
  }

  const itemPhotos = item.photos?.length || item.photo;
  const candidatePhotos = candidate.photos?.length || candidate.photo;
  if (itemPhotos && candidatePhotos && sameCategory) {
    score += 7;
    reasons.push('photos available for review');
  }

  const finalScore = Math.min(score, 100);
  if (finalScore < MATCH_THRESHOLD) return { score: 0, label: 'No match', reasons: [] };
  return {
    score: finalScore,
    label: finalScore >= 85 ? 'Very strong match' : 'Strong match',
    reasons
  };
}

function getBuilding(location) {
  const text = (location || '').toLowerCase();
  if (text.includes('library')) return 'Library';
  const block = text.match(/\bblock\s*([a-z0-9]+)\b/i) || text.match(/\b([a-z])\s*block\b/i);
  if (block) return 'Block ' + block[1].toUpperCase();
  if (text.includes('canteen')) return 'Canteen';
  if (text.includes('lab')) return 'Lab';
  return 'Other';
}

function filterByBuilding(item, building) {
  if (!building || building === 'all') return true;
  return getBuilding(item.location) === building;
}

function renderMatchBadge(item) {
  if (!item.match) return '';
  return `<div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;">
      <span class="badge ${item.match.score >= 85 ? 'found' : 'open'}">${escapeHtml(item.match.label)}</span>
      <span class="badge open">${item.match.score}% confidence</span>
    </div>
    <div style="font-size:11px;color:#777;line-height:1.45;margin-top:3px;">${escapeHtml(item.match.reasons.join(' | '))}</div>`;
}

function renderGallery(item) {
  const photos = item.photos?.length ? item.photos : (item.photo ? [item.photo] : []);
  if (!photos.length) return `<div class="detail-image">${escapeHtml(item.emoji || 'Item')}</div>`;
  return `
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-bottom:16px;">
      ${photos.map(photo => `<img src="${escapeAttr(photo)}" style="width:100%;height:180px;border:1px solid #ddd;border-radius:4px;object-fit:contain;background:#f9f9f9;">`).join('')}
    </div>`;
}

function timeAgo(iso) {
  const diff = (Date.now() - new Date(iso)) / 1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
  if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
  return Math.floor(diff / 86400) + 'd ago';
}

function formatDate(dateStr) {
  if (!dateStr) return '-';
  return new Date(dateStr).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

function showToast(msg) {
  let t = document.getElementById('toast');
  if (!t) {
    t = document.createElement('div');
    t.className = 'toast';
    t.id = 'toast';
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2500);
}

function renderThumb(item) {
  if (item.photo) {
    return `<img src="${escapeAttr(item.photo)}" style="width:56px;height:56px;object-fit:cover;border-radius:4px;border:1px solid #ddd;flex-shrink:0;">`;
  }
  return `<div style="width:56px;height:56px;border:1px solid #ddd;border-radius:4px;background:#f8f8f8;display:flex;align-items:center;justify-content:center;font-size:11px;color:#888;flex-shrink:0;">${escapeHtml(item.emoji || 'Item')}</div>`;
}

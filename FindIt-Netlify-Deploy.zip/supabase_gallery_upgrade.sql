alter table items
add column if not exists photo_urls jsonb default '[]'::jsonb;
